import cardImage from "../../assets/images/bg2.jpg";
const Places = [
    {
        title: 'Keynote Speaker 4',
        description:
            'Prof. Elizabeth initially trained as an electrical and electronic engineer at Canterbury University to pursue her interest in robotics.',
        imageUrl: cardImage,
        time: 1500,
    },
    {
        title: 'Keynote Speaker 3',
        description:
            'Prof. Elizabeth initially trained as an electrical and electronic engineer at Canterbury University to pursue her interest in robotics.',
        imageUrl: cardImage,
        time: 1500,
    },
    {
        title: 'Keynote Speaker 2',
        description:
            'Prof. Elizabeth initially trained as an electrical and electronic engineer at Canterbury University to pursue her interest in robotics.',
        imageUrl: cardImage,
        time: 1500,
    },
    {
        title: 'Keynote Speaker 1',
        description:
            'Prof. Elizabeth initially trained as an electrical and electronic engineer at Canterbury University to pursue her interest in robotics.',
        imageUrl: cardImage,
        time: 1500,
    },
];

export default Places;